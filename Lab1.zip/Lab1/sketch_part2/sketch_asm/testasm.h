unsigned int sumval(unsigned char a, unsigned char b);
unsigned int diffval(unsigned char a, unsigned char b);
unsigned int testasm(unsigned char a, unsigned char b);
