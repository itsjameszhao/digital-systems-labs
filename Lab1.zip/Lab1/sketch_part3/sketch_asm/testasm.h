unsigned int fib(unsigned char n);
